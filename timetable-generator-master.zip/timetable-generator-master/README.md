# timetable-generator
A timetable generator for IIT Mandi made on BootStrap with JavaScript.

To generate the timetable you have to fill the Course Code. Then choose the slots of the course. Atmost four slots can be filled for a course at a time which is pratical as well. Then, you can also fill the venue of the class. This is an additional feature of this timetable generator.

The easy steps to follow are:
	1. Clone the repository.
	2. Run on your browser/localhost.

The timetable-generator is also hosted at https://sylvia23.github.io/timetable-generator/
